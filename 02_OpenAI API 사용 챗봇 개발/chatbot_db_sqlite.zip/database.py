# database.py
import sqlite3

def init_db():
    conn = sqlite3.connect('chatbot.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS conversations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            question TEXT,
            answer TEXT
        )
    ''')
    conn.commit()
    conn.close()

def save_conversation(question, answer):
    conn = sqlite3.connect('chatbot.db')
    c = conn.cursor()
    c.execute('''
        INSERT INTO conversations (question, answer) VALUES (?, ?)
    ''', (question, answer))
    conn.commit()
    conn.close()

def get_conversations():
    conn = sqlite3.connect('chatbot.db')
    c = conn.cursor()
    c.execute('SELECT * FROM conversations')
    conversations = c.fetchall()
    conn.close()
    return conversations
