# 터미널에서 실행시
# python -m venv venv
# source venv/bin/activate  # 윈도우는 venv\Scripts\activate
# pip install -r requirements.txt
# python app.py


import os
from openai import OpenAI
from dotenv import load_dotenv
import sqlite3
from flask import Flask, render_template, request
from database import init_db, save_conversation, get_conversations

# .env 파일의 내용 불러오기
load_dotenv("C:/env/.env")

app = Flask(__name__)

# OpenAI API 키 설정
API_KEY= os.getenv("OPENAI_API_KEY")
client = OpenAI(api_key=API_KEY)


def get_response(user_message):
    #user_message = request.json.get("message")
    
    # OpenAI 모델에 요청
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[ {"role": "user", "content": user_message}],
        max_tokens=300,
        n=1,
        stop=None,
        temperature=0.7,
    )

    return  response.choices[0].message.content
    # return jsonify({"response": bot_response})


# 데이터베이스 초기화
init_db()

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        question = request.form['question']
        answer = get_response(question)
        save_conversation(question, answer)
        return render_template('index.html', question=question, answer=answer)
    return render_template('index.html')

@app.route('/history', methods=['GET'])
def history():
    conversations = get_conversations()
    return render_template('history.html', conversations=conversations)

if __name__ == '__main__':
    app.run(debug=False)





