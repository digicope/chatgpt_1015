import os
from flask import Flask, render_template, request, jsonify
import openai
from openai import OpenAI

from dotenv import load_dotenv

# .env 파일의 내용 불러오기
load_dotenv("C:/env/.env")

app = Flask(__name__)

# OpenAI API 키 설정
API_KEY= os.getenv("OPENAI_API_KEY")
client = OpenAI(api_key=API_KEY)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get_response", methods=["POST"])
def get_response():
    user_message = request.json.get("message")
    
    # OpenAI 모델에 요청
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[ {"role": "user", "content": user_message}],
        max_tokens=300,
        n=1,
        stop=None,
        temperature=0.7,
    )

    bot_response = response.choices[0].message.content
    return jsonify({"response": bot_response})

if __name__ == "__main__":
    app.run(debug=True)
