# database.py
from pymongo import MongoClient

# MongoDB에 연결
client = MongoClient('localhost', 27017)
db = client['chatbot']
conversations_collection = db['conversations']

def init_db():
    # MongoDB에서는 컬렉션이 필요할 때 자동으로 생성되므로 초기화 과정이 필요 없다.
    pass

def save_conversation(question, answer):
    conversation = {
        'question': question,
        'answer': answer
    }
    conversations_collection.insert_one(conversation)

def get_conversations():
    conversations = conversations_collection.find({})
    return list(conversations)

# 데이터베이스 연결 종료 (원한다면, 하지만 일반적으로 MongoDB 연결을 유지해도 문제 없습니다.)
def close_connection():
    client.close()